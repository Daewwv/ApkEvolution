const initialState = {
  route: 'login',
  user: { name: 'Marcos Silva', level: 3 },
  xp: 420,
  timerSeconds: 25 * 60,
  timerRunning: false,
  selectedMood: '🙂',
  goals: [
    { title: 'Melhorar o físico', category: 'Saúde', progress: 72 },
    { title: 'Organizar a vida financeira', category: 'Dinheiro', progress: 48 },
    { title: 'Estudar programação', category: 'Carreira', progress: 36 }
  ],
  missions: [
    { id: 1, goal: 'Saúde', title: 'Treinar 45 minutos', xp: 50, done: false, checklist: ['Aquecer 5 minutos', 'Treino principal', 'Registrar peso'] },
    { id: 2, goal: 'Dinheiro', title: 'Revisar gastos do dia', xp: 30, done: true, checklist: ['Abrir controle', 'Anotar despesas', 'Definir limite amanhã'] },
    { id: 3, goal: 'Carreira', title: 'Estudar 25 minutos', xp: 40, done: false, checklist: ['Abrir aula', 'Fazer anotações', 'Salvar resumo'] }
  ]
};

let state = JSON.parse(localStorage.getItem('progresslife-state')) || initialState;
let timerInterval = null;
const app = document.getElementById('app');
const title = document.getElementById('pageTitle');
const nav = document.getElementById('bottomNav');
const totalXp = document.getElementById('totalXp');

function save() { localStorage.setItem('progresslife-state', JSON.stringify(state)); }
function setRoute(route) { state.route = route; save(); render(); }
function pageName(route) {
  return ({ login:'Login', onboarding:'Onboarding', today:'Hoje', timer:'Timer', review:'Fechamento', weekly:'Progresso', profile:'Perfil' })[route];
}
function completedCount() { return state.missions.filter(m => m.done).length; }
function formatTime(s) { return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; }
function addXp(amount) { state.xp += amount; state.user.level = Math.max(1, Math.floor(state.xp / 250) + 1); }

function render() {
  title.textContent = pageName(state.route);
  totalXp.textContent = state.xp;
  nav.classList.toggle('hidden', ['login','onboarding'].includes(state.route));
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.route === state.route));
  const views = { login, onboarding, today, timer, review, weekly, profile };
  app.innerHTML = views[state.route]();
  bind();
}

function login() {
  return `
  <section class="card hero">
    <div class="logo">P</div>
    <h2>Transforme metas em missões diárias.</h2>
    <p>Um sistema simples para foco, disciplina, timer, XP e revisão diária.</p>
  </section>
  <section class="card">
    <div class="field"><label>E-mail</label><input placeholder="seuemail@email.com"></div>
    <div class="field"><label>Senha</label><input type="password" placeholder="••••••••"></div>
    <button class="btn" data-action="enter">Entrar</button>
    <button class="btn secondary" style="margin-top:10px" data-action="enter">Entrar com Google</button>
    <p class="muted">Protótipo: autenticação visual com dados locais.</p>
  </section>`;
}

function onboarding() {
  return `<section class="card"><h2>Escolha suas 3 metas</h2><p>Não coloque dez objetivos. O produto força foco: três metas principais.</p>${state.goals.map((g,i)=>`
    <div class="field"><label>Meta ${i+1}</label><input data-goal-title="${i}" value="${g.title}"></div>
    <div class="field"><label>Categoria</label><select data-goal-category="${i}"><option ${g.category==='Saúde'?'selected':''}>Saúde</option><option ${g.category==='Dinheiro'?'selected':''}>Dinheiro</option><option ${g.category==='Carreira'?'selected':''}>Carreira</option><option ${g.category==='Relacionamentos'?'selected':''}>Relacionamentos</option></select></div>`).join('')}
    <button class="btn" data-action="start">Começar minha jornada</button></section>`;
}

function today() {
  const date = new Date().toLocaleDateString('pt-BR', { weekday:'long', day:'2-digit', month:'long' });
  return `<section class="card"><h2>${date}</h2><p>${completedCount()} de ${state.missions.length} missões concluídas hoje.</p><div class="progress"><span style="width:${completedCount()/state.missions.length*100}%"></span></div></section>
  <section class="goal-grid">${state.goals.map(g=>`<div class="goal-card"><small>${g.category}</small><h3>${g.title}</h3><div class="progress"><span style="width:${g.progress}%"></span></div></div>`).join('')}</section>
  <section class="card"><h2>Missões de hoje</h2><div class="mission-list">${state.missions.map(m=>`<div class="mission-card"><small>${m.goal} • ${m.xp} XP</small><h3>${m.title}</h3><label class="check"><input type="checkbox" data-mission="${m.id}" ${m.done?'checked':''}><span>${m.done?'Concluída':'Marcar como concluída'}</span></label><button class="btn secondary" data-action="openTimer" data-id="${m.id}">Iniciar timer</button></div>`).join('')}</div></section>
  <button class="btn" data-action="review">Fechar o dia</button>`;
}

function timer() {
  const mission = state.missions.find(m => !m.done) || state.missions[0];
  return `<section class="card"><small>${mission.goal}</small><h2>${mission.title}</h2><div class="timer">${formatTime(state.timerSeconds)}</div><div class="btn-row"><button class="btn" data-action="toggleTimer">${state.timerRunning?'Pausar':'Iniciar'}</button><button class="btn warning" data-action="finishTimer">Finalizar</button></div></section>
  <section class="card"><h2>Checklist</h2>${mission.checklist.map(item=>`<label class="check"><input type="checkbox"><span>${item}</span></label>`).join('')}</section>`;
}

function review() {
  return `<section class="card"><h2>Fechamento do Dia</h2><div class="stat-grid"><div class="stat"><strong>${completedCount()}</strong><span>concluídas</span></div><div class="stat"><strong>${state.missions.length-completedCount()}</strong><span>pendentes</span></div></div></section>
  <section class="card"><h2>Como foi seu dia?</h2><div class="moods">${['😣','😐','🙂','😄','🔥'].map(m=>`<button class="mood ${state.selectedMood===m?'active':''}" data-mood="${m}">${m}</button>`).join('')}</div><div class="field" style="margin-top:14px"><label>Reflexão rápida</label><textarea placeholder="O que funcionou? O que precisa melhorar amanhã?"></textarea></div><button class="btn" data-action="saveReview">Salvar fechamento</button></section>`;
}

function weekly() {
  return `<section class="card"><h2>Progresso Semanal</h2><div class="stat-grid"><div class="stat"><strong>${state.xp}</strong><span>XP total</span></div><div class="stat"><strong>78%</strong><span>consistência</span></div></div></section>
  <section class="card"><h2>Últimos 7 dias</h2><div class="week">${['S','T','Q','Q','S','S','D'].map((d,i)=>`<div class="day ${i<5?'done':''}">${d}</div>`).join('')}</div></section>
  <section class="card"><h2>Resumo</h2><p>Você está criando ritmo. O próximo salto não é fazer mais coisas, é cumprir as missões certas sem negociar com a preguiça.</p>${state.goals.map(g=>`<h3>${g.title}</h3><div class="progress"><span style="width:${g.progress}%"></span></div>`).join('')}</section>`;
}

function profile() {
  return `<section class="card"><h2>${state.user.name}</h2><p>Nível ${state.user.level} • ${state.xp} XP acumulados</p><div class="progress"><span style="width:${state.xp%250/250*100}%"></span></div></section>
  <section class="card"><h2>Metas ativas</h2>${state.goals.map(g=>`<div class="goal-card"><small>${g.category}</small><h3>${g.title}</h3></div>`).join('')}<button class="btn secondary" style="margin-top:12px" data-action="editGoals">Editar metas</button><button class="btn secondary" style="margin-top:10px" data-action="logout">Sair</button></section>`;
}

function bind() {
  document.querySelectorAll('[data-route]').forEach(b => b.onclick = () => setRoute(b.dataset.route));
  document.querySelectorAll('[data-action]').forEach(b => b.onclick = () => handleAction(b.dataset.action, b.dataset.id));
  document.querySelectorAll('[data-mission]').forEach(c => c.onchange = () => {
    const m = state.missions.find(x => x.id == c.dataset.mission);
    if (m) { if (!m.done && c.checked) addXp(m.xp); m.done = c.checked; save(); render(); }
  });
  document.querySelectorAll('[data-mood]').forEach(b => b.onclick = () => { state.selectedMood = b.dataset.mood; save(); render(); });
  document.querySelectorAll('[data-goal-title]').forEach(i => i.oninput = () => { state.goals[i.dataset.goalTitle].title = i.value; save(); });
  document.querySelectorAll('[data-goal-category]').forEach(i => i.onchange = () => { state.goals[i.dataset.goalCategory].category = i.value; save(); });
}

function handleAction(action, id) {
  if (action === 'enter') setRoute('onboarding');
  if (action === 'start') setRoute('today');
  if (action === 'review') setRoute('review');
  if (action === 'saveReview') setRoute('weekly');
  if (action === 'openTimer') setRoute('timer');
  if (action === 'editGoals') setRoute('onboarding');
  if (action === 'logout') setRoute('login');
  if (action === 'toggleTimer') toggleTimer();
  if (action === 'finishTimer') { state.timerRunning = false; state.timerSeconds = 25*60; addXp(50); save(); setRoute('today'); }
}

function toggleTimer() {
  state.timerRunning = !state.timerRunning;
  save();
  if (state.timerRunning) startTimer(); else stopTimer();
  render();
}
function startTimer() {
  stopTimer();
  timerInterval = setInterval(() => {
    if (!state.timerRunning) return stopTimer();
    state.timerSeconds--;
    if (state.timerSeconds <= 0) { state.timerRunning = false; state.timerSeconds = 25*60; addXp(50); stopTimer(); }
    save(); render();
  }, 1000);
}
function stopTimer() { if (timerInterval) clearInterval(timerInterval); timerInterval = null; }

render();
if (state.timerRunning) startTimer();
